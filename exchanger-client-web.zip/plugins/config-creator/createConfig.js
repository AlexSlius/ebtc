const config = require("./index");
config.default("developers", [
  {
    name: "BoxExchanger",
    github: "https://gitlab.com/",
    mail: "@"
  }
]);
