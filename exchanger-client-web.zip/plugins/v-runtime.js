import Vue from "vue";
import VRuntimeTemplate from "v-runtime-template";
import VueRecaptcha from "vue-recaptcha";

Vue.component("v-runtime-template", VRuntimeTemplate);
Vue.component("recaptcha", VueRecaptcha);
