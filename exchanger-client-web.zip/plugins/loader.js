import Vue from "vue";
import load from "~/components/loader";

Vue.component("loader", load);
