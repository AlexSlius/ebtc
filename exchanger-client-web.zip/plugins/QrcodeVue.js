import Vue from "vue";
import QrcodeVue from "qrcode.vue";


Vue.component("QrcodeVue", QrcodeVue);
