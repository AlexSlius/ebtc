<template>
  <div class="under-header four-wr" style="min-height:81vh">
    <div class="four four-second">
      <div class="container text-center">
        <p>
          <img src="~assets/img/error.png" alt="" />
        </p>
        <p class="four-second-break">{{ $t("page.exchange.redirect.account_password_error") }}</p>
      </div>
    </div>
  </div>
</template>
<script>

export default {
};
</script>
