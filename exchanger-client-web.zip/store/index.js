export const strict = false;
