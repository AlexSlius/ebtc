
# Exchanger Web APP
>Beautiful and thoughtful design "Wrapper" is as important as the "stuffing". In Box Exchanger prepared for you the best combination of these qualities. Convenient design and beautiful styles for the exchanger.
> https://boxexchanger.net

## Build Setup

``` bash
$ npm install
$ npm run configure
```
configure `./config/app.json` set const to your project api `__proxy_to_rest_api`
```
$ npm run generate
```

### Development start
```
$ npm install
$ npm run configure
```
configure `./config/app.json` set const to your project api `__proxy_to_rest_api`
```
$ npm run dev
```
##### server with hot reload: http://localhost:3013
